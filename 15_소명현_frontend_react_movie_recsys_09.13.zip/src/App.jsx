import React from 'react';
import Recommendations from './pages/Recommendations'; // 본인의 Recommendations.jsx 파일 경로에 맞게 수정하세요 (예: './Recommendations')

function App() {
  return (
    <div>
      <Recommendations />
    </div>
  );
}

export default App;