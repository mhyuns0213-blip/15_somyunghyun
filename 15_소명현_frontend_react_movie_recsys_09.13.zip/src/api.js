import axios from 'axios'

const api = axios.create({
  baseURL: 'http://127.0.0.1:8000',
  headers: {
    'Content-Type': 'application/json',
  },
})

// 1. 회원 API
export async function fetchUsers(){
  const { data } = await api.get('/api/users')
  return data
}

export async function createUser(name){
  const { data } = await api.post('/api/users', { name })
  return data
}

export async function updateUser(userId, name){
  const { data } = await api.put(`/api/users/${userId}`, { name })
  return data
}

export async function deleteUser(userId){
  const { data } = await api.delete(`/api/users/${userId}`)
  return data
}

export async function fetchUserRatingDetails(userId){
  const { data } = await api.get(`/api/users/${userId}/ratings/detail`)
  return data
}

// 2. 영화 API
export async function fetchMovies(){
  const { data } = await api.get('/api/movies?limit=100')
  return data
}

export async function createMovie(movieData){
  const { data } = await api.post('/api/movies', movieData)
  return data
}

export async function updateMovie(movieId, movieData){
  const { data } = await api.put(`/api/movies/${movieId}`, movieData)
  return data
}

export async function deleteMovie(movieId){
  const { data } = await api.delete(`/api/movies/${movieId}`)
  return data
}

export async function fetchMovieAvgRating(movieId){
  const { data } = await api.get(`/api/movies/${movieId}/avg-rating`)
  return data
}

// 3. 평점 API
export async function upsertRating(userId, movieId, rating){
  const { data } = await api.post(`/api/users/${userId}/ratings`, { movie_id: Number(movieId), rating: Number(rating) })
  return data
}

export async function deleteRating(userId, movieId){
  const { data } = await api.delete(`/api/users/${userId}/ratings/${movieId}`)
  return data
}

// 4. 추천 API
export async function fetchRecommendations(userId, limit=12){
  const { data } = await api.get('/api/recommend', { params: { user_id: Number(userId), limit } })
  return data
}

export default api