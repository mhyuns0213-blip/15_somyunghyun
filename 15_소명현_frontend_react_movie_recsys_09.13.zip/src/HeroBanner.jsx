import React from 'react';
import './HeroBanner.css'; // CSS 파일 분리

function HeroBanner({ movies }) {
  // 영화 데이터가 없으면 렌더링하지 않음
  if (!movies || movies.length === 0) return null;

  // 인기가 가장 높은 영화를 히어로 배너로 선택 (또는 movies[0])
  const featuredMovie = movies.reduce((prev, current) => 
    (prev.popularity > current.popularity) ? prev : current, movies[0]
  );

  return (
    <div 
      className="hero-banner" 
      style={{ backgroundImage: `url(${featuredMovie.poster_url})` }}
    >
      {/* 어두운 그라데이션 오버레이 (텍스트 가시성 확보) */}
      <div className="hero-overlay">
        <div className="hero-content">
          <span className="hero-badge">TOP 랭킹 영화</span>
          <h1 className="hero-title">{featuredMovie.title}</h1>
          <p className="hero-meta">
            {featuredMovie.year}년 · {featuredMovie.genres}
          </p>
          <p className="hero-overview">
            {featuredMovie.overview 
              ? (featuredMovie.overview.length > 120 
                  ? featuredMovie.overview.slice(0, 120) + '...' 
                  : featuredMovie.overview) 
              : '줄거리 정보가 없습니다.'}
          </p>
          <div className="hero-buttons">
            <button className="hero-btn primary">▶ 재생/상세보기</button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default HeroBanner;