import React, { useEffect, useState } from 'react'
import { 
  fetchRecommendations, 
  fetchUsers, 
  createUser, 
  updateUser, 
  deleteUser,
  fetchMovies,
  createMovie,
  updateMovie,
  deleteMovie,
  upsertRating,
  deleteRating,
  fetchUserRatingDetails,
  fetchMovieAvgRating
} from '../api'
import MovieCard from '../components/MovieCard'
import HeroBanner from '../HeroBanner' 
import '../MovieCardGrid.css' 

export default function Recommendations(){
  const [recs, setRecs] = useState([])
  const [users, setUsers] = useState([])
  const [movies, setMovies] = useState([])
  
  const rawUserId = sessionStorage.getItem('user_id')
  const userId = rawUserId ? Number(rawUserId) : null

  const [selectedUserSelect, setSelectedUserSelect] = useState(rawUserId || '')
  const [newUserName, setNewUserName] = useState('')
  const [editUserId, setEditUserId] = useState(null)
  const [editUserName, setEditUserName] = useState('')

  const [newMovieTitle, setNewMovieTitle] = useState('')
  const [editMovieId, setEditMovieId] = useState(null)
  const [editMovieTitle, setEditMovieTitle] = useState('')

  const [selectedMovieId, setSelectedMovieId] = useState('')
  const [inputRating, setInputRating] = useState(5)
  const [userRatings, setUserRatings] = useState([])
  const [avgRatingResult, setAvgRatingResult] = useState(null)

  const loadData = async () => {
    try {
      const userList = await fetchUsers().catch(() => [])
      const movieList = await fetchMovies().catch(() => [])
      setUsers(userList || [])
      setMovies(movieList || [])
      
      if (userId) {
        const recData = await fetchRecommendations(userId, 12).catch(() => [])
        setRecs(recData || [])
        const ratingDetails = await fetchUserRatingDetails(userId).catch(() => [])
        setUserRatings(ratingDetails || [])
      }
    } catch (e) {
      console.error("데이터 로딩 중 에러 발생:", e)
    }
  }

  useEffect(() => {
    loadData()
  }, [userId])

  const handleUserChange = (e) => {
    const val = e.target.value
    setSelectedUserSelect(val)
    if (val) {
      sessionStorage.setItem('user_id', val)
    } else {
      sessionStorage.removeItem('user_id')
    }
    window.location.reload()
  }

  const handleCreateUser = async () => {
    if(!newUserName) return alert('회원 이름을 입력하세요.')
    await createUser(newUserName)
    setNewUserName('')
    alert('회원이 등록되었습니다.')
    loadData()
  }

  const handleUpdateUser = async (id) => {
    if(!editUserName) return alert('수정할 이름을 입력하세요.')
    await updateUser(id, editUserName)
    setEditUserId(null)
    setEditUserName('')
    alert('회원 정보가 수정되었습니다.')
    loadData()
  }

  const handleDeleteUser = async (id) => {
    if(window.confirm('정말 삭제하시겠습니까?')) {
      await deleteUser(id)
      alert('회원이 삭제되었습니다.')
      loadData()
    }
  }

  const handleCreateMovie = async () => {
    if(!newMovieTitle) return alert('영화 제목을 입력하세요.')
    await createMovie({ title: newMovieTitle })
    setNewMovieTitle('')
    alert('영화가 등록되었습니다.')
    loadData()
  }

  const handleUpdateMovie = async (id) => {
    if(!editMovieTitle) return alert('수정할 영화 제목을 입력하세요.')
    await updateMovie(id, editMovieTitle)
    setEditMovieId(null)
    setEditMovieTitle('')
    alert('영화 정보가 수정되었습니다.')
    loadData()
  }

  const handleDeleteMovie = async (id) => {
    if(window.confirm('영화 및 관련 평점을 삭제하시겠습니까?')) {
      await deleteMovie(id)
      alert('영화가 삭제되었습니다.')
      loadData()
    }
  }

  const handleSaveRating = async () => {
    if(!userId) return alert('먼저 상단에서 유저를 선택해 주세요!')
    if(!selectedMovieId) return alert('영화를 선택하세요.')
    await upsertRating(userId, selectedMovieId, inputRating)
    alert('평점이 저장되었습니다.')
    loadData()
  }

  const handleDeleteRating = async (movieId) => {
    await deleteRating(userId, movieId)
    alert('평점이 삭제되었습니다.')
    loadData()
  }

  const handleCheckAvgRating = async (movieId) => {
    if(!movieId) return setAvgRatingResult(null)
    const res = await fetchMovieAvgRating(movieId).catch(() => null)
    setAvgRatingResult(res)
  }

  return (
    <main style={{ padding: 20, maxWidth: 1200, margin: '0 auto', background: '#fff', color: '#000' }}>
      
      {/* 🎬 티빙 스타일 대형 히어로 배너 */}
      <HeroBanner movies={movies} />

      {/* 👤 사용자 선택 영역 */}
      <section style={{ background: '#e9ecef', padding: '15px 20px', borderRadius: 8, margin: '20px 0', display: 'flex', alignItems: 'center', gap: '15px', color: '#333' }}>
        <h3 style={{ margin: 0 }}>👤 사용자 선택:</h3>
        <select 
          value={selectedUserSelect} 
          onChange={handleUserChange}
          style={{ padding: '8px 12px', fontSize: '15px', borderRadius: '4px', border: '1px solid #ced4da', minWidth: '200px' }}
        >
          <option value="">-- 유저를 선택하세요 --</option>
          {users.map(u => (
            <option key={u.id} value={u.id}>[ID: {u.id}] {u.name}</option>
          ))}
        </select>
        {userId && <span style={{ color: '#28a745', fontWeight: 'bold' }}>✓ 현재 #{userId}번 유저 로그인 중</span>}
      </section>

      <h2>🎬 영화 추천 & 관리 시스템 {userId ? `(현재 회원 ID: #${userId})` : '(유저 미선택)'}</h2>

      {/* 관리자 패널 */}
      <section style={{ background: '#f5f5f5', padding: 15, borderRadius: 8, marginBottom: 20, color: '#333' }}>
        <h3>🛠 전체 관리 메뉴</h3>
        
        {/* 회원 관리 */}
        <div style={{ marginBottom: 15, borderBottom: '1px solid #ddd', paddingBottom: 10 }}>
          <h4>1. 회원 관리 (조회 / 추가 / 수정 / 삭제)</h4>
          <input 
            type="text" 
            placeholder="신규 회원 이름" 
            value={newUserName} 
            onChange={e => setNewUserName(e.target.value)} 
          />
          <button onClick={handleCreateUser} style={{ marginLeft: 5 }}>회원 추가</button>
          
          <ul style={{ marginTop: 10 }}>
            {users.map(u => (
              <li key={u.id} style={{ marginBottom: 5 }}>
                ID: {u.id} | 이름: 
                {editUserId === u.id ? (
                  <>
                    <input 
                      type="text" 
                      value={editUserName} 
                      onChange={e => setEditUserName(e.target.value)} 
                      style={{ marginLeft: 5, marginRight: 5 }}
                    />
                    <button onClick={() => handleUpdateUser(u.id)}>저장</button>
                    <button onClick={() => setEditUserId(null)} style={{ marginLeft: 3 }}>취소</button>
                  </>
                ) : (
                  <>
                    <strong> {u.name} </strong>
                    <button onClick={() => { setEditUserId(u.id); setEditUserName(u.name); }} style={{ marginLeft: 5 }}>수정</button>
                    <button onClick={() => handleDeleteUser(u.id)} style={{ marginLeft: 5, color: 'red' }}>삭제</button>
                  </>
                )}
              </li>
            ))}
          </ul>
        </div>

        {/* 영화 관리 */}
        <div style={{ marginBottom: 15, borderBottom: '1px solid #ddd', paddingBottom: 10 }}>
          <h4>2. 영화 관리 (조회 / 추가 / 수정 / 삭제) — 현재 영화 개수: {movies.length}개</h4>
          <div style={{ marginBottom: 15 }}>
            <input 
              type="text" 
              placeholder="신규 영화 제목" 
              value={newMovieTitle} 
              onChange={e => setNewMovieTitle(e.target.value)} 
            />
            <button onClick={handleCreateMovie} style={{ marginLeft: 5 }}>영화 추가</button>
          </div>

          {movies.length === 0 ? (
            <p style={{ color: 'red', fontWeight: 'bold' }}>⚠️ 등록된 영화 데이터가 없습니다. 위에서 영화를 추가해 주세요!</p>
          ) : (
            <div className="movie-grid">
              {movies.map(m => (
                <div key={m.id} className="movie-card">
                  <img 
                    src={m.poster_url || 'https://via.placeholder.com/160x240?text=No+Image'} 
                    alt={m.title} 
                    className="movie-poster" 
                  />
                  <div className="movie-card-info">
                    <h4 className="movie-card-title">{m.title}</h4>
                    <p className="movie-card-meta">{m.year || '2000'} · {m.genres || '장르'}</p>
                    
                    <div style={{ marginTop: 8 }}>
                      {editMovieId === m.id ? (
                        <div>
                          <input 
                            type="text" 
                            value={editMovieTitle} 
                            onChange={e => setEditMovieTitle(e.target.value)} 
                            style={{ width: '100%', marginBottom: 4 }}
                          />
                          <button onClick={() => handleUpdateMovie(m.id)} style={{ fontSize: '11px', marginRight: 4 }}>저장</button>
                          <button onClick={() => setEditMovieId(null)} style={{ fontSize: '11px' }}>취소</button>
                        </div>
                      ) : (
                        <div style={{ display: 'flex', gap: '5px' }}>
                          <button onClick={() => { setEditMovieId(m.id); setEditMovieTitle(m.title); }} style={{ fontSize: '11px', padding: '2px 6px' }}>수정</button>
                          <button onClick={() => handleDeleteMovie(m.id)} style={{ fontSize: '11px', padding: '2px 6px', color: 'red' }}>삭제</button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* 평점 등록/수정 */}
        <div style={{ marginBottom: 15, borderBottom: '1px solid #ddd', paddingBottom: 10 }}>
          <h4>3. 회원({userId ? `#${userId}` : '미선택'}) 영화별 평점 등록 및 수정</h4>
          <select value={selectedMovieId} onChange={e => setSelectedMovieId(e.target.value)}>
            <option value="">영화 선택</option>
            {movies.map(m => (
              <option key={m.id} value={m.id}>[{m.id}] {m.title}</option>
            ))}
          </select>
          <input 
            type="number" 
            min="0.5" 
            max="5" 
            step="0.5" 
            value={inputRating} 
            onChange={e => setInputRating(e.target.value)} 
            style={{ width: 60, marginLeft: 5, marginRight: 5 }}
          />점
          <button onClick={handleSaveRating}>평점 저장/수정</button>
        </div>

        {/* 영화별 평균 평점 조회 */}
        <div>
          <h4>4. 영화별 평균 평점 검색</h4>
          <select onChange={e => handleCheckAvgRating(e.target.value)}>
            <option value="">평균 평점을 확인할 영화 선택</option>
            {movies.map(m => (
              <option key={m.id} value={m.id}>[{m.id}] {m.title}</option>
            ))}
          </select>
          {avgRatingResult && (
            <span style={{ marginLeft: 10, fontWeight: 'bold', color: '#007bff' }}>
              평균 평점: ★ {avgRatingResult.average_rating} 점
            </span>
          )}
        </div>
      </section>

      {/* 회원별 평점 상세 조회 목록 */}
      <section style={{ marginBottom: 20 }}>
        <h3>⭐ 회원번호 {userId ? `#${userId}` : '미선택'}의 평점 남긴 영화 목록 (상세 조회)</h3>
        {!userId ? (
          <p style={{ color: '#6c757d' }}>상단에서 유저를 선택하시면 해당 유저의 평점 목록이 표시됩니다.</p>
        ) : userRatings.length === 0 ? (
          <p>등록된 평점이 없습니다.</p>
        ) : (
          <ul>
            {userRatings.map((r, i) => (
              <li key={i} style={{ marginBottom: 5 }}>
                영화번호: {r.movie_id} | 영화이름: <strong>{r.movie_title}</strong> | 평점: {r.rating}점
                <button onClick={() => handleDeleteRating(r.movie_id)} style={{ marginLeft: 10, color: 'red' }}>평점 삭제</button>
              </li>
            ))}
          </ul>
        )}
      </section>

      {/* AI 추천 영화 */}
      <section>
        <h3>🤖 AI 추천 영화 목록</h3>
        {!userId ? (
          <p style={{ color: '#6c757d' }}>유저를 선택하면 맞춤형 AI 추천 영화가 표시됩니다.</p>
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: 12 }}>
            {recs.map((r, idx) => (
              <MovieCard key={idx} movie={r.movie} score={r.score} />
            ))}
          </div>
        )}
      </section>
    </main>
  )
}