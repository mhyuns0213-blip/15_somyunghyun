from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routers import users, movies, recommend

app = FastAPI()

# CORS 설정 (모든 도메인 허용으로 확실하게 차단 방지)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def read_root():
    return {"message": "ok"}

# 라우터 연결
app.include_router(users.router)
app.include_router(movies.router)
app.include_router(recommend.router)