from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from ..db import get_db
from ..models import User, Rating, Movie
from ..schemas import UserCreate, UserUpdate, UserOut, UserRatingDetailOut, RatingCreate

router = APIRouter(prefix="/api/users", tags=["users"])

@router.get("", response_model=List[UserOut])
def get_users(db: Session = Depends(get_db)):
    return db.query(User).all()

@router.post("", response_model=UserOut)
def create_user(payload: UserCreate, db: Session = Depends(get_db)):
    user = User(name=payload.name)
    db.add(user)
    db.commit()
    db.refresh(user)
    return user

@router.put("/{user_id}", response_model=UserOut)
def update_user(user_id: int, payload: UserUpdate, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    user.name = payload.name
    db.commit()
    db.refresh(user)
    return user

@router.delete("/{user_id}")
def delete_user(user_id: int, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    db.delete(user)
    db.commit()
    return {"message": "User deleted successfully"}

# 회원별 평점 상세 조회 (영화번호, 영화이름, 영화평점)
@router.get("/{user_id}/ratings/detail", response_model=List[UserRatingDetailOut])
def get_user_rating_details(user_id: int, db: Session = Depends(get_db)):
    results = (
        db.query(Rating.movie_id, Movie.title, Rating.rating)
        .join(Movie, Rating.movie_id == Movie.id)
        .filter(Rating.user_id == user_id)
        .all()
    )
    return [{"movie_id": r.movie_id, "movie_title": r.title, "rating": r.rating} for r in results]

# 평점 등록 및 수정 (Upsert)
@router.post("/{user_id}/ratings")
def upsert_rating(user_id: int, payload: RatingCreate, db: Session = Depends(get_db)):
    rating = db.query(Rating).filter(Rating.user_id == user_id, Rating.movie_id == payload.movie_id).first()
    if rating:
        rating.rating = payload.rating
    else:
        rating = Rating(user_id=user_id, movie_id=payload.movie_id, rating=payload.rating)
        db.add(rating)
    db.commit()
    return {"message": "Rating saved successfully"}

# 평점 삭제
@router.delete("/{user_id}/ratings/{movie_id}")
def delete_rating(user_id: int, movie_id: int, db: Session = Depends(get_db)):
    rating = db.query(Rating).filter(Rating.user_id == user_id, Rating.movie_id == movie_id).first()
    if not rating:
        raise HTTPException(status_code=404, detail="Rating not found")
    db.delete(rating)
    db.commit()
    return {"message": "Rating deleted successfully"}