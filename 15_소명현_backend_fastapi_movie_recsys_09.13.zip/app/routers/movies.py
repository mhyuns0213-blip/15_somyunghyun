from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import List
from ..db import get_db
from ..models import Movie, Rating
from ..schemas import MovieCreate, MovieUpdate, MovieOut, MovieAvgRatingOut

router = APIRouter(prefix="/api/movies", tags=["movies"])

@router.get("", response_model=List[MovieOut])
def get_movies(limit: int = 100, db: Session = Depends(get_db)):
    return db.query(Movie).limit(limit).all()

@router.post("", response_model=MovieOut)
def create_movie(payload: MovieCreate, db: Session = Depends(get_db)):
    movie = Movie(
        title=payload.title,
        genres=payload.genres,
        overview=payload.overview,
        year=payload.year,
        poster_url=payload.poster_url,
        popularity=payload.popularity
    )
    db.add(movie)
    db.commit()
    db.refresh(movie)
    return movie

@router.put("/{movie_id}", response_model=MovieOut)
def update_movie(movie_id: int, payload: MovieUpdate, db: Session = Depends(get_db)):
    movie = db.query(Movie).filter(Movie.id == movie_id).first()
    if not movie:
        raise HTTPException(status_code=404, detail="Movie not found")
    movie.title = payload.title
    db.commit()
    db.refresh(movie)
    return movie

@router.delete("/{movie_id}")
def delete_movie(movie_id: int, db: Session = Depends(get_db)):
    movie = db.query(Movie).filter(Movie.id == movie_id).first()
    if not movie:
        raise HTTPException(status_code=404, detail="Movie not found")
    db.delete(movie)
    db.commit()
    return {"message": "Movie deleted successfully"}

# 영화별 평균 평점 조회
@router.get("/{movie_id}/avg-rating", response_model=MovieAvgRatingOut)
def get_movie_avg_rating(movie_id: int, db: Session = Depends(get_db)):
    movie = db.query(Movie).filter(Movie.id == movie_id).first()
    if not movie:
        raise HTTPException(status_code=404, detail="Movie not found")
    
    avg_score = db.query(func.avg(Rating.rating)).filter(Rating.movie_id == movie_id).scalar()
    return {
        "movie_id": movie_id,
        "average_rating": round(float(avg_score), 2) if avg_score is not None else 0.0
    }