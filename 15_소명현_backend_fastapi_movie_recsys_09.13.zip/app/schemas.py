from pydantic import BaseModel, RootModel
from typing import Optional, List

# User Schemas
class UserCreate(BaseModel):
    name: str

class UserUpdate(BaseModel):
    name: str

class UserOut(BaseModel):
    id: int
    name: str

    class Config:
        from_attributes = True

# Movie Schemas
class MovieCreate(BaseModel):
    title: str
    genres: Optional[str] = None
    overview: Optional[str] = None
    year: Optional[int] = None
    poster_url: Optional[str] = None
    popularity: Optional[float] = 0.0

class MovieUpdate(BaseModel):
    title: str
    genres: Optional[str] = None
    overview: Optional[str] = None
    year: Optional[int] = None
    poster_url: Optional[str] = None
    popularity: Optional[float] = 0.0

class MovieOut(BaseModel):
    id: int
    title: str
    genres: Optional[str] = None
    overview: Optional[str] = None
    year: Optional[int] = None
    poster_url: Optional[str] = None
    popularity: Optional[float] = 0.0

    class Config:
        from_attributes = True

# Rating Schemas
class RatingCreate(BaseModel):
    movie_id: int
    rating: float

class UserRatingDetailOut(BaseModel):
    movie_id: int
    movie_title: str
    rating: float

    class Config:
        from_attributes = True

class MovieAvgRatingOut(BaseModel):
    movie_id: int
    average_rating: float

    class Config:
        from_attributes = True

# Recommendation Schemas
class RecommendationItem(BaseModel):
    movie: MovieOut
    score: float

class RecommendationOut(RootModel[List[RecommendationItem]]):
    pass